"""
Run management service for tracking pipeline executions.

Storage strategy:
- Active (pending/running) runs are updated in-memory for the hot path and also
    snapshotted to Firestore so other instances can serve fresh admin reads.
- Completed/failed/cancelled runs are persisted to Firestore (collection: "pipeline_runs")
  via a single-threaded background writer so the hot path is never blocked.
- Local dev (no FIRESTORE_PROJECT env var): completed runs live in an in-memory dict and
  are lost on restart — acceptable for local experimentation.

Firestore is the single source of truth; there is no local-file sync and no GCS run storage.

Write ordering guarantee: all Firestore writes go through a single-threaded executor
(ThreadPoolExecutor with max_workers=1). Snapshots are taken in the calling thread
before submitting, so each submission captures the exact state at the moment of the call
and writes are always applied in FIFO order. This prevents the race condition where
multiple writes spawned in rapid succession (e.g. step-upfront creation, fast step
transitions) could land on Firestore out of order and produce an inconsistent step-status
view on page reload.
"""

import logging
import os
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .models import RunInfo, RunOptions, RunRequest, RunStatus, RunStep

logger = logging.getLogger("pipeline")

_COLLECTION = "pipeline_runs"

# Maximum completed runs kept in the local-dev in-memory history.
# Prevents unbounded memory growth during long-running local sessions.
_MAX_LOCAL_HISTORY = 200


class RunManager:
    """Manages pipeline run lifecycle and state."""

    def __init__(self):
        self.active_runs: Dict[str, RunInfo] = {}
        self._log_handlers: Dict[str, Any] = {}
        # Completed-run store: Firestore client in production, in-memory dict in local dev
        self._db: Optional[Any] = None  # google.cloud.firestore.Client when available
        self._local_history: Dict[str, RunInfo] = {}  # local dev fallback
        # Single-threaded executor ensures Firestore writes are always applied in FIFO
        # order, preventing stale out-of-order writes from producing inconsistent state
        # on page reload.
        self._write_executor: ThreadPoolExecutor = ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="fs-writer"
        )
        self._init_store()

    def _init_store(self) -> None:
        """Connect to Firestore if FIRESTORE_PROJECT is set, else use in-memory fallback.

        On Cloud Run: FIRESTORE_PROJECT is required. Fail fast if missing.
        """
        project = os.getenv("FIRESTORE_PROJECT")
        is_cloud_run = bool(os.getenv("K_SERVICE") or os.getenv("CLOUD_RUN_SERVICE"))

        if not project:
            if is_cloud_run:
                raise RuntimeError(
                    "Cloud Run detected but FIRESTORE_PROJECT is not set. "
                    "Run history requires Firestore for durability. "
                    "Set FIRESTORE_PROJECT via Terraform/deployment scripts."
                )
            logger.info("RunManager: FIRESTORE_PROJECT not set — using in-memory run history (local dev mode)")
            return
        try:
            from google.cloud import firestore  # type: ignore
            self._db = firestore.Client(project=project)
            logger.info("RunManager: using Firestore project=%s collection=%s", project, _COLLECTION)
        except ImportError:
            if is_cloud_run:
                raise RuntimeError("Cloud Run detected but google-cloud-firestore not installed.")
            logger.warning("google-cloud-firestore not installed; using in-memory run history")
        except Exception as e:
            if is_cloud_run:
                raise RuntimeError(f"Cloud Run detected but failed to initialize Firestore: {e}")
            logger.exception("Firestore init failed; using in-memory run history")

    class RunLogHandler(logging.Handler):
        def __init__(self, run_manager, run_id):
            super().__init__()
            self.run_manager = run_manager
            self.run_id = run_id
            self._emitting = False  # re-entrancy guard

        def emit(self, record):
            # Guard against recursive calls (e.g. _save_run failing and logging the error)
            if self._emitting:
                return
            self._emitting = True
            try:
                log_entry = {
                    "level": record.levelname.lower(),
                    "message": record.getMessage(),
                    "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
                    "logger": record.name,
                    "filename": record.filename,
                    "funcName": record.funcName,
                    "lineno": record.lineno,
                }
                self.run_manager.add_run_log(self.run_id, log_entry)
            finally:
                self._emitting = False

    def attach_run_logger(self, run_id: str, logger_name: Optional[str] = None):
        """Attach a logging handler to capture logs for this run.

        Scoped to the 'pipeline' logger by default (not root) to avoid
        cross-run log bleed when multiple runs overlap.
        """
        if run_id in self._log_handlers:
            return  # Already attached
        handler = self.RunLogHandler(self, run_id)
        handler.setLevel(logging.DEBUG)
        target = logger_name or "pipeline"
        logger = logging.getLogger(target)
        logger.addHandler(handler)
        self._log_handlers[run_id] = (handler, logger)

    def detach_run_logger(self, run_id: str):
        """Detach the logging handler for this run."""
        if run_id in self._log_handlers:
            handler, logger = self._log_handlers.pop(run_id)
            logger.removeHandler(handler)

    def _load_runs(self):
        pass  # No-op: replaced by Firestore-primary storage (no startup sync needed)

    def create_run(self, steps: List[str], request: RunRequest) -> RunInfo:
        """Create a new pipeline run."""
        run_id = str(uuid.uuid4())

        # Merge options
        options = {}
        if request.options:
            options = request.options.model_dump(exclude_unset=True)

        run_info = RunInfo(
            run_id=run_id,
            status=RunStatus.PENDING,
            payload=request.payload,
            options=options,
            started_at=datetime.now(timezone.utc),
            steps=[RunStep(name=s) for s in steps],
        )

        self.active_runs[run_id] = run_info
        # Attach logs list to run_info
        run_info.logs = []
        self._save_run(run_info)
        return run_info

    def add_step(self, run_id: str, step: str) -> Optional[RunStep]:
        """Append a new step to an existing run."""
        run_info = self.active_runs.get(run_id)
        if not run_info:
            return None
        step_info = RunStep(name=step)
        run_info.steps.append(step_info)
        self._save_run(run_info)
        return step_info

    def update_step_status(
        self,
        run_id: str,
        step: str,
        status: RunStatus,
        artifact_id: Optional[str] = None,
        duration_ms: Optional[int] = None,
        error: Optional[str] = None,
    ):
        """Update status information for a specific step."""
        run_info = self.active_runs.get(run_id)
        if not run_info:
            return
        for step_info in run_info.steps:
            if step_info.name == step:
                step_info.status = status
                if status == RunStatus.RUNNING:
                    step_info.started_at = datetime.now(timezone.utc)
                if status in [RunStatus.COMPLETED, RunStatus.FAILED]:
                    step_info.completed_at = datetime.now(timezone.utc)
                    step_info.duration_ms = duration_ms
                    step_info.artifact_id = artifact_id
                    step_info.error = error
                    if artifact_id:
                        run_info.artifact_id = artifact_id
                break
        self._save_run(run_info)

    def start_run(self, run_id: str):
        """Mark a run as started."""
        if run_id in self.active_runs:
            self.active_runs[run_id].status = RunStatus.RUNNING
            self.attach_run_logger(run_id)
            self._save_run(self.active_runs[run_id])

    def complete_run(self, run_id: str, artifact_id: Optional[str] = None, duration_ms: Optional[int] = None) -> Optional["RunInfo"]:
        """Mark a run as completed. Returns the final RunInfo (or None if not found)."""
        if run_id in self.active_runs:
            run_info = self.active_runs[run_id]
            run_info.status = RunStatus.COMPLETED
            run_info.completed_at = datetime.now(timezone.utc)
            run_info.artifact_id = artifact_id
            run_info.duration_ms = duration_ms
            del self.active_runs[run_id]
            self.detach_run_logger(run_id)
            self._persist_background(run_info)
            return run_info
        return None

    def fail_run(self, run_id: str, error: str, duration_ms: Optional[int] = None) -> Optional["RunInfo"]:
        """Mark a run as failed. Returns the final RunInfo (or None if not found)."""
        if run_id in self.active_runs:
            run_info = self.active_runs[run_id]
            run_info.status = RunStatus.FAILED
            run_info.completed_at = datetime.now(timezone.utc)
            run_info.error = error
            run_info.duration_ms = duration_ms
            del self.active_runs[run_id]
            self.detach_run_logger(run_id)
            self._persist_background(run_info)
            return run_info
        return None

    def cancel_run(self, run_id: str) -> Optional["RunInfo"]:
        """Cancel a running process. Returns the final RunInfo (or None if not found)."""
        if run_id in self.active_runs:
            run_info = self.active_runs[run_id]
            run_info.status = RunStatus.CANCELLED
            run_info.completed_at = datetime.now(timezone.utc)
            del self.active_runs[run_id]
            self.detach_run_logger(run_id)
            self._persist_background(run_info)
            return run_info
        # The run may have already left active_runs (agent task finished or
        # crashed) but still be sitting in local cache / Firestore with a
        # stale "running" or "pending" status.  Update it so the UI can
        # proceed to delete it.
        run_info = self._local_history.get(run_id)
        if run_info is None and self._db is not None:
            try:
                doc = self._db.collection(_COLLECTION).document(run_id).get()
                if doc.exists:
                    run_info = RunInfo(**(doc.to_dict() or {}))
            except Exception:
                logger.exception("Firestore get failed during cancel fallback for run %s", run_id)
        if run_info and run_info.status in (RunStatus.PENDING, RunStatus.RUNNING):
            run_info.status = RunStatus.CANCELLED
            run_info.completed_at = datetime.now(timezone.utc)
            self._persist_background(run_info)
            return run_info
        return None

    def delete_run(self, run_id: str) -> bool:
        """Delete a completed/failed/cancelled run from history. Returns True if deleted."""
        if run_id in self.active_runs:
            return False  # Cannot delete an active run; cancel it first
        # Always evict from local cache so get_run() stops returning it
        self._local_history.pop(run_id, None)
        if self._db is not None:
            try:
                doc_ref = self._db.collection(_COLLECTION).document(run_id)
                if not doc_ref.get().exists:
                    return False
                doc_ref.delete()
                return True
            except Exception:
                logger.exception("Firestore delete failed for run %s", run_id)
                return False
        else:
            # local-only mode: cache eviction above was the delete
            return True

    def get_run(self, run_id: str) -> Optional[RunInfo]:
        """Get run information."""
        if run_id in self.active_runs:
            return self.active_runs[run_id]
        # Check local cache first — covers the window between active_runs
        # removal and the async Firestore write completing.
        cached = self._local_history.get(run_id)
        if cached is not None:
            return cached
        if self._db is not None:
            try:
                doc = self._db.collection(_COLLECTION).document(run_id).get()
                if doc.exists:
                    data = doc.to_dict() or {}
                    return RunInfo(**data)
            except Exception:
                logger.exception("Firestore get failed for run %s", run_id)
        return None

    def list_active_runs(self) -> List[RunInfo]:
        """List all active runs.

        In Cloud Run, merge local hot-path state with Firestore snapshots so admin
        reads stay consistent across instances.
        """
        runs: List[RunInfo] = list(self.active_runs.values())
        active_ids = set(self.active_runs.keys())

        if self._db is not None:
            try:
                docs = self._db.collection(_COLLECTION).stream()
                for doc in docs:
                    data = doc.to_dict() or {}
                    run_id = data.get("run_id")
                    status = data.get("status")
                    if run_id in active_ids or status not in (RunStatus.PENDING, RunStatus.RUNNING, "pending", "running"):
                        continue
                    try:
                        runs.append(RunInfo(**data))
                    except Exception:
                        logger.warning("Skipping corrupt active run doc %s", doc.id, exc_info=True)
            except Exception:
                logger.exception("Firestore list_active_runs query failed")

        def _sort_key(r: RunInfo):
            dt = r.started_at
            if dt is None:
                return datetime.min.replace(tzinfo=timezone.utc)
            if dt.tzinfo is None:
                return dt.replace(tzinfo=timezone.utc)
            return dt

        runs.sort(key=_sort_key, reverse=True)
        return runs

    def list_recent_runs(self, limit: int = 50) -> List[RunInfo]:
        """List recent runs (active in memory + history from Firestore)."""
        runs: List[RunInfo] = list(self.active_runs.values())
        active_ids = set(self.active_runs.keys())

        if self._db is not None:
            try:
                from google.cloud.firestore import Query  # type: ignore
                docs = (
                    self._db.collection(_COLLECTION)
                    .order_by("started_at", direction=Query.DESCENDING)
                    .limit(limit)
                    .stream()
                )
                for doc in docs:
                    data = doc.to_dict() or {}
                    if data.get("run_id") not in active_ids:
                        try:
                            runs.append(RunInfo(**data))
                        except Exception as e:
                            logger.warning("Skipping malformed run doc %s: %s", doc.id, e)
            except Exception:
                logger.exception("Firestore list_recent_runs query failed")
        else:
            for run_id, run_info in self._local_history.items():
                if run_id not in active_ids:
                    runs.append(run_info)

        def _sort_key(r):
            dt = r.started_at
            if dt is None:
                return datetime.min.replace(tzinfo=timezone.utc)
            if dt.tzinfo is None:
                return dt.replace(tzinfo=timezone.utc)
            return dt

        runs.sort(key=_sort_key, reverse=True)
        return runs[:limit]

    def add_run_log(self, run_id: str, log: dict):
        """Add a log entry to a run (in-memory only for active runs)."""
        run_info = self.active_runs.get(run_id)
        if run_info:
            if not hasattr(run_info, "logs") or run_info.logs is None:
                run_info.logs = []
            run_info.logs.append(log)

    def get_run_logs(self, run_id: str):
        run_info = self.get_run(run_id)
        if run_info and hasattr(run_info, "logs"):
            return run_info.logs
        return []

    def _save_run(self, run_info: RunInfo):
        """Persist active run state to Firestore so step progress survives page refreshes.

        The snapshot is taken in the calling thread so it captures the exact run state
        at the moment of the call. The write is submitted to a single-threaded executor
        so all writes are applied in FIFO order, preventing out-of-order Firestore updates.
        """
        if self._db is not None:
            # Snapshot NOW in the calling thread (not inside the background task).
            # This guarantees: (a) each write reflects the state at the moment _save_run
            # was called, and (b) the single-threaded executor ensures writes land in the
            # order they were submitted — no stale write can overwrite a newer one.
            data = run_info.model_dump(mode="json")
            data.pop("logs", None)  # logs are ephemeral; not stored in Firestore
            self._write_executor.submit(self._write_firestore_data, run_info.run_id, data)

    def _persist_background(self, run_info: RunInfo) -> None:
        """Fire-and-forget: persist a completed/failed/cancelled run to Firestore (or local dict)."""
        # Always cache locally so get_run() can find the run immediately
        # (before the async Firestore write finishes).
        self._local_history[run_info.run_id] = run_info
        if len(self._local_history) > _MAX_LOCAL_HISTORY:
            oldest_key = next(iter(self._local_history))
            del self._local_history[oldest_key]

        if self._db is not None:
            data = run_info.model_dump(mode="json")
            data.pop("logs", None)  # logs are ephemeral; not stored in Firestore
            self._write_executor.submit(self._write_firestore_data, run_info.run_id, data)

    def _write_firestore_data(self, run_id: str, data: dict) -> None:
        """Write a pre-serialized run snapshot to Firestore (runs inside the write executor)."""
        if self._db is None:
            return
        try:
            self._db.collection(_COLLECTION).document(run_id).set(data)
        except Exception:
            logger.exception("Firestore write failed for run %s", run_id)

    # sync_from_gcs is intentionally removed: Firestore is now the source of truth.

    def shutdown(self, wait: bool = True) -> None:
        """Shut down the background write executor.

        Called automatically on process exit via Python's atexit (ThreadPoolExecutor
        registers this internally), but can also be called explicitly — e.g. in tests
        or when replacing the singleton.  *wait=True* blocks until pending writes finish.
        """
        self._write_executor.shutdown(wait=wait)


# Global run manager instance
run_manager = RunManager()
